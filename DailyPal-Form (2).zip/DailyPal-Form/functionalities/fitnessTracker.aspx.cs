﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class fitnessTracker : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    TextBox1.Text = Session["UserId"].ToString();
                    TextBox5.Text = Session["UserName"].ToString();
                }
            }

            GenerateWeightChart(); // Call the method to generate the weight chart
            getdata(); // Call the getdata method to load assignment data
        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        protected void Button1_Click(object sender, EventArgs e)
        {
            string type = DropDownList1.SelectedValue.ToString();
            int duration = int.Parse(TextBox2.Text);
            string level = DropDownList2.SelectedValue.ToString(), caloriesburned = TextBox3.Text, goal = TextBox4.Text, personalization = TextBox6.Text, device = TextBox7.Text;
            string social = DropDownList3.SelectedValue.ToString();
           
            string jdate = Calendar1.SelectedDate.ToString();
            int id = int.Parse(Session["UserID"].ToString());

            conn.Open();
            string query = "Insert into FitnessTracker(date,id,WorkoutType,Duration,IntensityLevel,CaloriesBurned,FitnessGoal,Personalization,IntegrationDevice,SocialSharing) values" +
                " ('" + jdate + "','" + id + "','" + type + "','" + duration + "','" + level + "','" + caloriesburned + "','" + goal + "','" + personalization + "','" + device + "','" + social + "') ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        void getdata()
        {
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                SqlCommand command = new SqlCommand("SELECT * FROM FitnessTracker WHERE id = @UserId", conn);
                command.Parameters.AddWithValue("@UserId", id);

                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int fitnessId = int.Parse(TextBox1.Text);

            string type = DropDownList1.SelectedValue.ToString();
            int duration = int.Parse(TextBox2.Text);
            string level = DropDownList2.SelectedValue.ToString();
            string caloriesburned = TextBox3.Text;
            string goal = TextBox4.Text;
            string personalization = TextBox6.Text;
            string device = TextBox7.Text;
            string social = DropDownList3.SelectedValue.ToString();
          
            DateTime jdate = Calendar1.SelectedDate;
            int userId = int.Parse(Session["UserID"].ToString());

            conn.Open();
            string query = "UPDATE FitnessTracker SET " +
                           "Height = @height, " +
                           "Mass = @mass, " +
                           "Date = @jdate, " +
                           "ID = @userId, " +
                           "WorkoutType = @type, " +
                           "Duration = @duration, " +
                           "IntensityLevel = @level, " +
                           "CaloriesBurned = @caloriesBurned, " +
                           "FitnessGoal = @goal, " +
                           "Personalization = @personalization, " +
                           "IntegrationDevice = @device, " +
                           "SocialSharing = @social " +
                           "WHERE FitnessID = @fitnessId";

            SqlCommand com = new SqlCommand(query, conn);
            
            com.Parameters.AddWithValue("@jdate", jdate);
            com.Parameters.AddWithValue("@userId", userId);
            com.Parameters.AddWithValue("@type", type);
            com.Parameters.AddWithValue("@duration", duration);
            com.Parameters.AddWithValue("@level", level);
            com.Parameters.AddWithValue("@caloriesBurned", caloriesburned);
            com.Parameters.AddWithValue("@goal", goal);
            com.Parameters.AddWithValue("@personalization", personalization);
            com.Parameters.AddWithValue("@device", device);
            com.Parameters.AddWithValue("@social", social);
            com.Parameters.AddWithValue("@fitnessId", fitnessId);

            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success!');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int fitnessId = int.Parse(TextBox11.Text);
            conn.Open();
            string query = "delete from FitnessTracker where FitnessId=@id";

            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@id", fitnessId);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success!');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }

        private void GenerateWeightChart()
        {
            DataTable dt = GetWeightAndDateData();

            Chart1.DataSource = dt;
            Chart1.DataBind();
        }

        private DataTable GetWeightAndDateData()
        {
            DataTable dt = new DataTable();
            conn.Open();

            string query = @"SELECT ft.Date AS XValue, d.weight AS YValue
                     FROM FitnessTracker ft
                     JOIN diet d ON ft.id = d.id
                     WHERE ft.id = @UserId";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@UserId", Session["UserId"]);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dt);

            conn.Close();
            return dt;
        }
    }
}