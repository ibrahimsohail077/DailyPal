﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class ShoppingList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox1.Text = Session["UserId"].ToString();
                    TextBox2.Text = Session["UserName"].ToString();

                }

            }
            getdata();
        }
        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM ShoppingList WHERE UserID = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", Session["UserId"]);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = TextBox4.Text;
            string unit = DropDownList2.SelectedValue.ToString();
            string listname = TextBox6.Text;
            string priority = DropDownList3.SelectedValue.ToString();
            DateTime date = Calendar1.SelectedDate;
            string quantity = RadioButtonList1.SelectedValue.ToString();
            string cat = DropDownList1.SelectedValue.ToString();
            int userid = int.Parse(Session["UserId"].ToString());
            conn.Open();
            string query = "INSERT INTO ShoppingList(Category,UserID,Name, Unit, Quantity, ListName, CreationDate, Priority)" +
                " VALUES ('" + cat + "','" + userid + "','" + name + "','" + unit + "','" + quantity + "','" + listname + "','" + date.ToString("yyyy-MM-dd") + "','" + priority + "')";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string name = TextBox4.Text;
            string unit = DropDownList2.SelectedValue.ToString();
            string listname = TextBox6.Text;
            string priority = DropDownList3.SelectedValue.ToString();
            DateTime date = Calendar1.SelectedDate;
            string quantity = RadioButtonList1.SelectedValue.ToString();
            int shoppingListID = int.Parse(TextBox3.Text); // Replace 123 with the actual ShoppingListID value
            string cat = DropDownList1.SelectedValue.ToString();
            conn.Open();
            string query = "UPDATE ShoppingList SET Name = '" + name + "', Unit = '" + unit + "', Category = '" + cat + "', Quantity = '" + quantity + "', ListName = '" + listname + "', CreationDate = '" + date.ToString("yyyy-MM-dd") + "', Priority = '" + priority + "' WHERE ShoppingListID = " + shoppingListID;
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Update Successful');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int listid = int.Parse(TextBox3.Text);
            conn.Open();
            string query = "delete from ShoppingList where ShoppingListID=@id";


            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@id", listid);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success!');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }
    }
}