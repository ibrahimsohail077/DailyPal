﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class dietanage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox1.Text = Session["UserId"].ToString();
                    TextBox5.Text = Session["UserName"].ToString();

                }

            }
            getdata(); // Call the getdata method to load assignment data
            CaloriesBurned();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        protected void Button1_Click(object sender, EventArgs e)
        {


            string des = TextBox8.Text;
            string name = TextBox9.Text, type = DropDownList1.SelectedValue.ToString();
            int height=int.Parse(TextBox10.Text);
            string mass=TextBox11.Text,goals=TextBox12.Text,calories=TextBox13.Text;
            int id = int.Parse(Session["UserId"].ToString());
            conn.Open();
            string query = "Insert into diet(id,info,foodname,mealtype,goals,height,weight,calories) values " +
                "('" + id + "','" + des + "','" + name + "','" + type + "','" + goals + "','" + height + "','" + mass + "','" + calories + "') ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }

        private void CaloriesBurned()
        {
            // Open connection
            conn.Open();

            // Example of calculating total calories consumed
            string query = "SELECT SUM(calories) AS TotalCalories FROM diet WHERE id = @UserId";
            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@UserId", Session["UserId"]);
            int totalCalories = Convert.ToInt32(com.ExecuteScalar());

            // Display the aggregated information or store it in variables for further use
            TextBox15.Text = totalCalories.ToString();

            // Close connection
            conn.Close();
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            string des = TextBox8.Text;
            string name = TextBox9.Text;
            string type = DropDownList1.SelectedValue;
            string goals = TextBox12.Text;
            int height = int.Parse(TextBox10.Text);
            string mass = TextBox11.Text;
            string calories = TextBox13.Text;

            try
            {
                conn.Open();
                int id = int.Parse(TextBox14.Text); // Retrieve ID from session
                string query = "UPDATE diet SET description = @description, name = @name, type = @type, goals = @goals, height = @height, mass = @mass, calories = @calories WHERE id = @id";
                SqlCommand com = new SqlCommand(query, conn);
                com.Parameters.AddWithValue("@description", des);
                com.Parameters.AddWithValue("@name", name);
                com.Parameters.AddWithValue("@type", type);
                 com.Parameters.AddWithValue("@height", height);
                com.Parameters.AddWithValue("@mass", mass);
                com.Parameters.AddWithValue("@calories", calories);
                com.Parameters.AddWithValue("@id", id); // Use ID from session
                com.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success');", true);
            }
            catch (Exception ex)
            {
                // Display an error message if update fails
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", $"alert('An error occurred: {ex.Message}');", true);
            }
            finally
            {
                conn.Close();
            }

        }
        void getdata()
        {
            if (Session["UserId"] != null)
            {
                SqlCommand command = new SqlCommand("SELECT * FROM diet WHERE id = @UserId", conn);
                command.Parameters.AddWithValue("@UserId", Session["UserId"]);

                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);

                // Calculate BMI for each record and add it to the DataTable
                dt.Columns.Add("BMI", typeof(double));
                foreach (DataRow row in dt.Rows)
                {
                    double weight = Convert.ToDouble(row["weight"]);
                    int height = Convert.ToInt32(row["height"]);
                    double heightInMeters = height;// Convert height to meters
                    double bmi = weight / (heightInMeters * heightInMeters);
                    row["BMI"] = bmi;
                }

                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        } 

        protected void Button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(TextBox14.Text);
           
            conn.Open();
            string query = "delete from  diet where DietID=  '" + id + "' ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Page_Load(sender, e);
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }
    }
}