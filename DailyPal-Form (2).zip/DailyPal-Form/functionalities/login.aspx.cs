﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
       

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("./functionalities/signpage.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("./user_login.aspx");
        }

       

        protected void Unnamed3_Click(object sender, EventArgs e)
        {
            Response.Redirect("ad.aspx");
        }
    }
}