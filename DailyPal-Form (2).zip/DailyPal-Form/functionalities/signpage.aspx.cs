﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form
{
    public partial class signpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");
       

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("./user_login.aspx");
        }

        protected void create(object sender, EventArgs e)
        {
            string username = TextBox1.Text;
            string password = TextBox2.Text;
            string gender = DropDownList1.SelectedValue;
            string email = TextBox3.Text;

            // Check if email is null or empty
            if (string.IsNullOrEmpty(email))
            {
                // Display an error message to the user
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Email cannot be empty.');", true);
                return; // Exit the method
            }

            try
            {
                conn.Open();
                string query = "INSERT INTO userdata (name, password, gender, email) VALUES (@name, @password, @gender, @email)";
                SqlCommand com = new SqlCommand(query, conn);
                com.Parameters.AddWithValue("@name", username);
                com.Parameters.AddWithValue("@password", password);
                com.Parameters.AddWithValue("@gender", gender);
                com.Parameters.AddWithValue("@email", email);
                com.ExecuteNonQuery();

                Response.Redirect("./user_login.aspx");
                // Retrieve the newly created user's ID
                SqlCommand getUserIdCommand = new SqlCommand("SELECT Id FROM userdata WHERE name = @name", conn);
                getUserIdCommand.Parameters.AddWithValue("@name", username);
                int userId = (int)getUserIdCommand.ExecuteScalar();

                // Store UserId and UserName in session variables
                Session["UserId"] = userId;
                Session["UserName"] = username;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success');", true);
                Response.Redirect("~/Homescreen/homescreen.aspx");
            }
            catch (Exception ex)
            {
                // Display an error message if insertion fails
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", $"alert('An error occurred: {ex.Message}');", true);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}