﻿using Antlr.Runtime.Tree;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class Expense : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox5.Text = Session["UserId"].ToString();
                    TextBox6.Text = Session["UserName"].ToString();

                }

            }
            getdata(); // Call the getdata method to load assignment data
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            int amount = int.Parse(TextBox2.Text);
            string category = DropDownList1.SelectedValue.ToString(), method = DropDownList1.SelectedValue.ToString(), des = TextBox4.Text;

            DateTime transdate = Calendar1.SelectedDate;
            int id = int.Parse(Session["UserId"].ToString());
            conn.Open();
            string query = "Insert into ExpenseTracker(UserID,ExpenseName,Amount,Category,TransactionDate,PaymentMethod)" +
                " values ('" + id + "','" + name + "','" + amount + "','" + category + "','" + transdate + "','" + method + "') ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
            Page_Load(sender, e);
        }
        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM ExpenseTracker WHERE UserID = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", id);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            int amount = int.Parse(TextBox2.Text);
            string category = DropDownList1.SelectedValue.ToString();
            string method = DropDownList2.SelectedValue.ToString();
            string des = TextBox4.Text;
            DateTime transdate = Calendar1.SelectedDate;
            int expenseId = int.Parse(TextBox7.Text); // Assuming you have a TextBox to get the ExpenseId

            conn.Open();

            // Update query
            string updateQuery = "UPDATE ExpenseTracker SET ExpenseName = @ExpenseName, Amount = @Amount, Category = @Category, " +
                                 "TransactionDate = @TransactionDate, PaymentMethod = @PaymentMethod, Description = @Description " +
                                 "WHERE ExpenseId = @ExpenseId";

            SqlCommand com = new SqlCommand(updateQuery, conn);
            com.Parameters.AddWithValue("@ExpenseName", name);
            com.Parameters.AddWithValue("@Amount", amount);
            com.Parameters.AddWithValue("@Category", category);
            com.Parameters.AddWithValue("@TransactionDate", transdate.ToString("yyyy-MM-dd"));
            com.Parameters.AddWithValue("@PaymentMethod", method);
            com.Parameters.AddWithValue("@Description", des);
            com.Parameters.AddWithValue("@ExpenseId", expenseId);

            int rowsAffected = com.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Update successful');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('No rows were updated');", true);
            }

            conn.Close();
            Page_Load(sender, e);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(TextBox7.Text);

            conn.Open();
            string query = "delete from ExpenseTracker  where ExpenseID=  '" + id + "' ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }
    }
}