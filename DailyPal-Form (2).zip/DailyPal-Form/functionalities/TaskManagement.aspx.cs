﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class TaskManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox3.Text = Session["UserId"].ToString();
                    TextBox5.Text = Session["UserName"].ToString();

                }


            }
            LoadTaskStatusData();
            getdata(); // Call the getdata method to load assignment data
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM task WHERE UserID = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", id);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {

            string name = TextBox1.Text;
            string des = TextBox2.Text, priority = DropDownList1.SelectedValue.ToString(), status = DropDownList2.SelectedValue.ToString(), choice = RadioButtonList1.SelectedValue.ToString();
            int id = int.Parse(Session["UserId"].ToString()) ;
            DateTime duedate = Calendar1.SelectedDate, sdate = Calendar2.SelectedDate;

            conn.Open();
            string query = "Insert into task(UserID,TaskName,Description,Priority,DueDate,StartingDate,CompletionStatus,urgent)  values" +
                " ('" + id + "','" + name + "','" + des + "','" + priority + "','" + duedate + "','" + sdate + "','" + status + "','" + choice + "') ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
            Page_Load(sender, e);

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            string des = TextBox2.Text, priority = DropDownList1.SelectedValue.ToString(), status = DropDownList2.SelectedValue.ToString(), choice = RadioButtonList1.SelectedValue.ToString();
            int id = int.Parse(TextBox6.Text);
            DateTime duedate = Calendar1.SelectedDate, sdate = Calendar2.SelectedDate;

            conn.Open();
            string query = "UPDATE task SET TaskName = @name, Description = @des, Priority = @priority, DueDate = @duedate, CompletionStatus = @status, urgent = @choice WHERE TaskID = @id";
            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@des", des);
            com.Parameters.AddWithValue("@priority", priority);
            com.Parameters.AddWithValue("@duedate", duedate);
            com.Parameters.AddWithValue("@status", status);
            com.Parameters.AddWithValue("@choice", choice);
            com.Parameters.AddWithValue("@id", id);

            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
            Page_Load(sender, e);

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(TextBox6.Text);
            conn.Open();
            string query = "delete from task where TaskID=@id";


            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@id", id);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success!');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        private void LoadTaskStatusData()
        {
            // Query to get the count of each task status
            conn.Open();
            string query = "SELECT CompletionStatus, COUNT(*) AS TotalCount FROM task WHERE UserID = @UserId GROUP BY CompletionStatus";

           
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@UserId", Session["UserId"].ToString());
                
                SqlDataReader reader = command.ExecuteReader();

                // Clear any existing data in the chart series
                Chart1.Series["Series1"].Points.Clear();

                while (reader.Read())
                {
                    string status = reader["CompletionStatus"].ToString();
                    int count = Convert.ToInt32(reader["TotalCount"]);

                    // Add data points to the chart series based on task status
                    Chart1.Series["Series1"].Points.AddXY(status, count);
                }

                conn.Close();
            

            // Set chart properties
            Chart1.Series["Series1"].IsValueShownAsLabel = true;
            Chart1.Series["Series1"].LegendText = "#VALX (#PERCENT{P0})";
            Chart1.Series["Series1"].Label = "#VALX (#PERCENT{P0})";
        }
        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }
    }
}