﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.DataVisualization.Charting;

namespace DailyPal_Form
{
    public partial class assignment : System.Web.UI.Page
    {
        string cs = System.Configuration.ConfigurationManager.ConnectionStrings["dbcs2"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox6.Text = Session["UserId"].ToString();
                    TextBox7.Text = Session["UserName"].ToString();
                    
                }
               
            }
            getdata(); // Call the getdata method to load assignment data
            loadChart();
        }


        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");
        private object completed;

       

        protected void create(object sender, EventArgs e)
        {

            int id=int.Parse(TextBox6.Text);
            string course = TextBox2.Text, status = DropDownList1.SelectedValue.ToString(), des = TextBox4.Text;
            DateTime jdate = Calendar1.SelectedDate;
            
            conn.Open();
            string query = "Insert into AssignmentManage(Id,course,Description,status,DueDate) values ('" + id + "','" + course + "','" + des + "','" + status + "','" + jdate + "') ";
            SqlCommand com = new SqlCommand(query,conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }

        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM AssignmentManage WHERE id = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", id);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }


        protected void update(object sender, EventArgs e)
        {
            // Parse input values
            int id = int.Parse(TextBox6.Text);
            string course = TextBox2.Text;
            string status = DropDownList1.SelectedValue;
            string des = TextBox4.Text;
            DateTime jdate = Calendar1.SelectedDate;
            int ass_id = int.Parse(TextBox8.Text);

            // Open connection
            conn.Open();

            // Define SQL query with parameters
            string query = "UPDATE AssignmentManage SET Id = @id, course = @course, Description = @des, DueDate = @jdate, status = @status WHERE AssignmentID = @assignmentID";

            // Create SqlCommand object with query and connection
            SqlCommand com = new SqlCommand(query, conn);

            // Add parameters
            com.Parameters.AddWithValue("@id", id);
            com.Parameters.AddWithValue("@course", course);
            com.Parameters.AddWithValue("@des", des);
            com.Parameters.AddWithValue("@jdate", jdate);
            com.Parameters.AddWithValue("@status", status);

            // Add AssignmentID parameter
            com.Parameters.AddWithValue("@assignmentID", ass_id); // Assuming you have a variable named AssignmentID to specify the AssignmentID to update

            try
            {
                // Execute query
                int rowsAffected = com.ExecuteNonQuery();

                // Check if any rows were affected
                if (rowsAffected > 0)
                {
                    // If successful, show success message
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success!');", true);
                }
                else
                {
                    // If no rows were affected, show error message
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('No records updated.');", true);
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('An error occurred: " + ex.Message + "');", true);
            }
            finally
            {
                // Close connection
                conn.Close();
            }
        }


        protected void Button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(TextBox8.Text);
            string course = TextBox2.Text, status = DropDownList1.SelectedValue.ToString(), des = TextBox4.Text;
            DateTime jdate = Calendar1.SelectedDate;
            conn.Open();
            string query = "delete from  AssignmentManage where AssignmentId=  '" + id + "' ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }
        void loadChart()
        {
            // Create a DataTable to store the data retrieved from the database
            DataTable dt = new DataTable();

            try
            {
                conn.Open();
                // Define the SQL command to retrieve the status distribution
                SqlCommand command = new SqlCommand("SELECT status, COUNT(status) AS Distribution FROM AssignmentManage WHERE Id = @UserId GROUP BY status", conn);
                // Set the parameter for the user ID
                command.Parameters.AddWithValue("@UserId", Session["UserId"]); // Use the Session["UserId"] as parameter

                // Execute the command and fill the DataTable with the results
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

            // Clear any existing series in the chart
            Chart1.Series.Clear();

            // Add a new series to the chart
            Series series = new Series("StatusDistribution");

            // Specify the chart type (e.g., Pie)
            series.ChartType = SeriesChartType.StackedColumn;

            // Add data points to the series based on the status distribution retrieved from the database
            foreach (DataRow row in dt.Rows)
            {
                string status = row["status"].ToString();
                int count = Convert.ToInt32(row["Distribution"]);
                series.Points.AddXY(status, count);
            }

            // Add the series to the chart
            Chart1.Series.Add(series);
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            try
            {
                string statusToDelete = DropDownList1.SelectedValue; // Retrieve selected status
                conn.Open();
                string query = "DELETE FROM AssignmentManage WHERE status = @status";
                SqlCommand com = new SqlCommand(query, conn);
                com.Parameters.AddWithValue("@status", statusToDelete); // Use the retrieved status
                int rowsAffected = com.ExecuteNonQuery();
                conn.Close();

                if (rowsAffected > 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success: Rows deleted.');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('No rows deleted.');", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", $"alert('An error occurred: {ex.Message}');", true);
            }
            finally
            {
                conn.Close();
            }
        }

        protected void load(object sender, EventArgs e)
        {
            Page_Load(sender, e);
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }
    }
}