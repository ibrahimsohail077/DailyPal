﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class Habit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox6.Text = Session["UserId"].ToString();
                    TextBox7.Text = Session["UserName"].ToString();

                }

            }
            GenerateHabitStatusChart();
            getdata(); // Call the getdata method to load assignment data
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            string status = DropDownList1.SelectedValue.ToString();
            string notes = TextBox4.Text;
            string frequency = DropDownList2.SelectedValue.ToString();
            string progress = DropDownList4.SelectedValue.ToString();
            string change = DropDownList3.SelectedValue.ToString();
            DateTime sdate = Calendar2.SelectedDate;
            int id = int.Parse(Session["UserId"].ToString());

            conn.Open();
            string query = "Insert into Habit(UserID,HabitName,Frequency,StartDate,Progress,HabitStatus,CHANGESTATUS,Notes) values" +
                " ('" + id + "','" + name + "','" + frequency + "','" + sdate + "','" +progress  + "','" + status + "','" +status  + "','" + notes + "') ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }
        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM Habit WHERE UserId = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", id);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            string status = DropDownList1.SelectedValue.ToString();
            string notes = TextBox4.Text;
            string frequency = DropDownList2.SelectedValue.ToString();
            string progress = DropDownList4.SelectedValue.ToString();
            string change = DropDownList3.SelectedValue.ToString();
            DateTime sdate = Calendar2.SelectedDate;
            int id = int.Parse(Session["UserId"].ToString());
            int habitId = int.Parse(TextBox8.Text); 

            conn.Open();

            // Update query
            string updateQuery = "UPDATE Habit SET HabitName = @HabitName, Frequency = @Frequency, StartDate = @StartDate, " +
                                 "Progress = @Progress, HabitStatus = @HabitStatus, CHANGESTATUS = @CHANGESTATUS, Notes = @Notes " +
                                 "WHERE HabitID = @HabitId ";

            SqlCommand com = new SqlCommand(updateQuery, conn);
            com.Parameters.AddWithValue("@HabitName", name);
            com.Parameters.AddWithValue("@Frequency", frequency);
            com.Parameters.AddWithValue("@StartDate", sdate.ToString("yyyy-MM-dd"));
            com.Parameters.AddWithValue("@Progress", progress);
            com.Parameters.AddWithValue("@HabitStatus", status);
            com.Parameters.AddWithValue("@CHANGESTATUS", change);
            com.Parameters.AddWithValue("@Notes", notes);
            com.Parameters.AddWithValue("@HabitId", habitId);
            com.Parameters.AddWithValue("@UserId", id);

            int rowsAffected = com.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Update successful');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('No rows were updated');", true);
            }

            conn.Close();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(TextBox8.Text);

            conn.Open();
            string query = "delete from  Habit where HabitID=  '" + id + "' ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }
        private void GenerateHabitStatusChart()
        {
            DataTable dt = GetHabitStatusDistribution();

            // Clear any existing series in the chart
            Chart1.Series.Clear();

            // Add a new series to the chart
            Series series = new Series("StatusDistribution");

            // Specify the chart type (e.g., Stacked Column)
            series.ChartType = SeriesChartType.StackedColumn;

            // Add data points to the series based on the status distribution retrieved from the database
            foreach (DataRow row in dt.Rows)
            {
                string status = row["HabitStatus"].ToString();
                int count = Convert.ToInt32(row["Count"]);
                series.Points.AddXY(status, count);
            }

            // Add the series to the chart
            Chart1.Series.Add(series);
        }

        private DataTable GetHabitStatusDistribution()
        {
            DataTable dt = new DataTable();
            conn.Open();

            string query = "SELECT HabitStatus, COUNT(*) AS Count FROM Habit WHERE UserId = @UserId GROUP BY HabitStatus";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@UserId", Session["UserId"]);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dt);

            conn.Close();
            return dt;
        }
    }
}