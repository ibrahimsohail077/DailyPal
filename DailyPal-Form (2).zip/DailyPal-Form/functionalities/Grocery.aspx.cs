﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static IronPython.Modules._ast;
using static IronPython.Modules.PythonDateTime;

namespace DailyPal_Form.functionalities
{
    public partial class Grocery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox6.Text = Session["UserId"].ToString();
                    TextBox7.Text = Session["UserName"].ToString();

                }

            }
            load_list(sender,e); // Call the getdata method to load assignment data
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM assignment WHERE id = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", id);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            string des = TextBox4.Text;
            string status = RadioButtonList2.SelectedValue.ToString();

            DateTime exp = Calendar1.SelectedDate;
            DateTime purchase = Calendar2.SelectedDate;
            int price = int.Parse(TextBox5.Text);
            int id = int.Parse(Session["UserId"].ToString());
            int sid = int.Parse(TextBox8.Text);

            conn.Open();
            string query = "INSERT INTO GroceryManagement(UserID, ExpiryDate, PurchaseDate, Price, ShoppingListID, Status, Notes) " +
                           "VALUES (@UserID, @ExpiryDate, @PurchaseDate, @Price, @ShoppingListID, @Status, @Notes)";

            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@UserID", id);
            com.Parameters.AddWithValue("@ExpiryDate", exp.ToString("yyyy-MM-dd"));
            com.Parameters.AddWithValue("@PurchaseDate", purchase.ToString("yyyy-MM-dd"));
            com.Parameters.AddWithValue("@Price", price);
            com.Parameters.AddWithValue("@ShoppingListID", sid);
            com.Parameters.AddWithValue("@Status", status);
            com.Parameters.AddWithValue("@Notes", des);

            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success');", true);
            conn.Close();

            conn.Open();
            string joinQuery = "SELECT gm.*, sl.Name, sl.Unit, sl.Category, sl.Quantity, sl.ListName, sl.CreationDate, sl.Priority " +
                               "FROM GroceryManagement gm " +
                               "INNER JOIN ShoppingList sl ON gm.ShoppingListID = sl.ShoppingListID where sl.UserID=@id and gm.Status=@avail ";

            string available = "Available";
            SqlCommand joinCom = new SqlCommand(joinQuery, conn);
            joinCom.Parameters.AddWithValue("@id", id);
            joinCom.Parameters.AddWithValue("@avail",available );
            SqlDataAdapter adapter = new SqlDataAdapter(joinCom);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            // Calculate the total price
            int totalPrice = 0;
            foreach (DataRow row in dt.Rows)
            {
                totalPrice += Convert.ToInt32(row["Price"]);
            }

            // Bind the DataTable to a GridView or other controls to display the data
            GridView1.DataSource = dt;
            GridView1.DataBind();

            // Set the total price in a TextBox
            TextBox9.Text = totalPrice.ToString();

            // Get the sum of prices grouped by category
            string categoryQuery = "SELECT sl.Category, SUM(gm.Price) AS TotalPrice " +
                       "FROM GroceryManagement gm " +
                       "INNER JOIN ShoppingList sl ON gm.ShoppingListID = sl.ShoppingListID " +
                       "WHERE sl.UserID = @id " +
                       "GROUP BY sl.Category";
            SqlCommand categoryCommand = new SqlCommand(categoryQuery, conn);
            categoryCommand.Parameters.AddWithValue("@id", Session["UserId"]);
            SqlDataAdapter categoryAdapter = new SqlDataAdapter(categoryCommand);
            DataTable categoryTable = new DataTable();
            categoryAdapter.Fill(categoryTable);

            // Bind the category data to a GridView
            GridView3.DataSource = categoryTable;
            GridView3.DataBind();

            conn.Close();
        }
        void load_list(object sender, EventArgs e)
        {
            conn.Open();
            string query = "SELECT * FROM ShoppingList WHERE UserID = @id";

            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@id", Session["UserId"]);

            SqlDataAdapter sd = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            sd.Fill(dt); 

            if (dt.Rows.Count > 0)
            {
                GridView2.DataSource = dt;
                GridView2.DataBind();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('No data found!');", true);
            }

            conn.Close();
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }
    }
}