﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.Homescreen
{
    public partial class homescreen : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void b1(object sender, EventArgs e)
        {
            Response.Redirect("./Habit.aspx");
        }
    }
}