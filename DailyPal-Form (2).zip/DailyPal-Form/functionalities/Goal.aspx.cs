﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class Goal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox5.Text = Session["UserId"].ToString();
                    TextBox6.Text = Session["UserName"].ToString();

                }

            }
            getdata(); // Call the getdata method to load assignment data
        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        protected void Button2_Click(object sender, EventArgs e)
        {
            // Retrieve input values
            string name = TextBox1.Text;
            string cat = DropDownList1.SelectedValue;
            string progress = DropDownList2.SelectedValue;
            string des = TextBox4.Text;
            DateTime jdate = Calendar1.SelectedDate;
            int goalId = int.Parse(TextBox7.Text); // Assuming you're passing the goalId as a query string parameter

            // Open connection
            conn.Open();

            // Define SQL query with parameters
            string query = "UPDATE Goal SET GoalName = @name, Category = @cat, Description = @des, TargetDate = @jdate, Progress = @progress WHERE GoalID = @goalId";

            // Create SqlCommand object with query and connection
            SqlCommand com = new SqlCommand(query, conn);

            // Add parameters
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@cat", cat);
            com.Parameters.AddWithValue("@des", des);
            com.Parameters.AddWithValue("@jdate", jdate);
            com.Parameters.AddWithValue("@progress", progress);
            com.Parameters.AddWithValue("@goalId", goalId);
            Page_Load(sender,e);

            try
            {
                // Execute query
                int rowsAffected = com.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    // Show success message
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Update successful!');", true);
                }
                else
                {
                    // Show no rows updated message
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('No rows were updated.');", true);
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", $"alert('An error occurred: {ex.Message}');", true);
            }
            finally
            {
                // Close connection
                conn.Close();
            }
        }
        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM Goal WHERE UserID = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", id);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Retrieve input values
            string name = TextBox1.Text;
            string cat = DropDownList1.SelectedValue;
            string progress = DropDownList2.SelectedValue;
            string des = TextBox4.Text;
            DateTime jdate = Calendar1.SelectedDate;
          

            // Open connection
            conn.Open();

            // Define SQL query with parameters
            string query = "INSERT INTO Goal (UserID, GoalName, Category, Description, TargetDate, Progress) " +
                           "VALUES (@userId, @name, @cat, @des, @jdate, @progress)";

            // Create SqlCommand object with query and connection
            SqlCommand com = new SqlCommand(query, conn);

            // Add parameters
            com.Parameters.AddWithValue("@userId", Session["UserId"]);
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@cat", cat);
            com.Parameters.AddWithValue("@des", des);
            com.Parameters.AddWithValue("@jdate", jdate);
            com.Parameters.AddWithValue("@progress", progress);

            try
            {
                // Execute query
                com.ExecuteNonQuery();

                // Show success message
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success!');", true);
            }
            catch (Exception ex)
            {
                // Handle exceptions
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", $"alert('An error occurred: {ex.Message}');", true);
            }
            finally
            {
                // Close connection
                conn.Close();
            }
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(TextBox7.Text);

            conn.Open();
            string query = "delete from  Goal where GoalID=  '" + id + "' ";
            SqlCommand com = new SqlCommand(query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
        }
    }
}