﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyPal_Form.functionalities
{
    public partial class sleepingRoutine : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    // Retrieve the user ID from session variable and set it to TextBox1
                    TextBox5.Text = Session["UserId"].ToString();
                    TextBox6.Text = Session["UserName"].ToString();

                }

            }
            getdata(); // Call the getdata method to load assignment data
            LoadSleepQualityData();
        }
        void getdata()
        {
            // Ensure Session["UserId"] is not null and parse it to an integer
            if (Session["UserId"] != null)
            {
                int id = int.Parse(Session["UserId"].ToString());

                // Use a parameterized query to avoid SQL injection
                SqlCommand command = new SqlCommand("SELECT * FROM sleeping WHERE id = @UserId", conn);
                // Add parameter to the SqlCommand
                command.Parameters.AddWithValue("@UserId", id);

                // Execute the query
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Muhammad Abrahim\source\repos\DailyPal-Form\DailyPal-Form\App_Data\Dailydb.mdf;Integrated Security=True");

        protected void Button1_Click(object sender, EventArgs e)
        {
            String bedtime = TextBox2.Text, waketime = TextBox3.Text;
            int duration = int.Parse(TextBox4.Text);
            int id = int.Parse(Session["UserId"].ToString());
            String category = DropDownList1.SelectedValue.ToString(), method = DropDownList1.SelectedValue.ToString(), des = TextBox4.Text;
            String quality = DropDownList1.SelectedValue.ToString();

            conn.Open();

            // Convert bedtime and waketime strings to TimeSpan
            TimeSpan bedtimeTime = TimeSpan.Parse(bedtime);
            TimeSpan waketimeTime = TimeSpan.Parse(waketime);

            String Query = "Insert into sleeping(id,bedtime,waketime,sleepduration,quality) values ('" + id + "','" + bedtimeTime + "','" + waketimeTime + "','" + duration + "','" + quality + "') ";
            SqlCommand com = new SqlCommand(Query, conn);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
            Page_Load(sender, e);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string bedtime = TextBox2.Text, waketime = TextBox3.Text;
            int duration = int.Parse(TextBox4.Text);
            int id = int.Parse(TextBox5.Text);
            string category = DropDownList1.SelectedValue.ToString(), method = DropDownList1.SelectedValue.ToString(), des = TextBox4.Text;
            string quality = DropDownList1.SelectedValue.ToString();

            conn.Open();
            string query = "UPDATE sleeping SET bedtime = @bedtime, waketime = @waketime, sleepduration = @duration, quality = @quality WHERE id = @id";
            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@bedtime", bedtime);
            com.Parameters.AddWithValue("@waketime", waketime);
            com.Parameters.AddWithValue("@duration", duration);
            com.Parameters.AddWithValue("@quality", quality);
            com.Parameters.AddWithValue("@id", id);

            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('success');", true);
            conn.Close();
            Page_Load(sender, e);

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(TextBox5.Text);
            conn.Open();
            string query = "delete from sleeping where SleepID=@id";


            SqlCommand com = new SqlCommand(query, conn);
            com.Parameters.AddWithValue("@id", id);
            com.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Success!');", true);
            conn.Close();
            Page_Load(sender, e);
        }
        private void LoadSleepQualityData()
        {
            // Query to get the count of each sleep quality category
            conn.Open();
            string query = "SELECT quality, COUNT(*) AS TotalCount FROM sleeping GROUP BY quality";

            
            
                SqlCommand command = new SqlCommand(query, conn);
                
                SqlDataReader reader = command.ExecuteReader();

                // Create a dictionary to store the sleep quality data
                Dictionary<string, int> sleepQualityData = new Dictionary<string, int>();

                while (reader.Read())
                {
                    string quality = reader["quality"].ToString();
                    int count = Convert.ToInt32(reader["TotalCount"]);

                    // Add the sleep quality data to the dictionary
                    sleepQualityData[quality] = count;
                }

                conn.Close();

                // Add data points to the chart series based on sleep quality category
                foreach (var item in sleepQualityData)
                {
                    Chart1.Series["SleepQuality"].Points.AddXY(item.Key, item.Value);
                }
            

            // Set chart properties
            Chart1.Series["SleepQuality"].IsValueShownAsLabel = true;
            Chart1.Series["SleepQuality"]["PieLabelStyle"] = "Outside";
            Chart1.Series["SleepQuality"]["PieDrawingStyle"] = "SoftEdge";
            Chart1.Series["SleepQuality"].LegendText = "#VALX (#PERCENT{P0})";
            Chart1.Series["SleepQuality"].Label = "#VALX (#PERCENT{P0})";
        }
        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Homescreen/homescreen.aspx");
        }
    }
}